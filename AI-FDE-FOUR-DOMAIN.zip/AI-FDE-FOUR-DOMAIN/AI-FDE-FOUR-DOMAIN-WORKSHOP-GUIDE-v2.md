# AI FDE Brownfield Four-Domain Workshop — v2

## What this is
Four **independent synthetic brownfield simulations**: manufacturing batch release, banking AML investigations, healthcare claims review, energy-grid outage response. Each includes runnable Python/SQLite legacy logic, synthetic data, contracts, events, adversarial conditions, scenario catalog, seven sequential prompt exercises, and an artifact contract.

## Seven-stage learning journey
1. Business Problem → business problem, constraints and evidence
2. C4 Context → C1 actors, integrations, trust boundaries
3. GenAI Patterns → feasible candidates + non-AI baseline
4. C4 Design → C2/C3 candidates, dynamic and failure diagrams
5. Trade-off Matrix → hard gates, weights, measurements and uncertainty
6. ADR → proposed/accepted decision, rationale and consequences
7. Validate → evaluation cases, experiment plan, measurements, triggers

## How to run (in EACH unzipped repo root)
```bash
python -m scripts.seed
python -m legacy.service RECORD_ID
python -m unittest discover -s tests -v
python -m scripts.check_repo
python -m scripts.check_artifacts
```

Use RECORD_ID: manufacturing=B-100, banking=AL-1, healthcare=CL-1, energy=O-1. `scripts.check_artifacts` is expected to return status 1 before the workshop because the 7-stage outputs are intentionally NOT provided. The seed script overwrites local demo.sqlite3.

## Strict interpretation of validation
- Test suite passing means simulated CLI behavior and repository integrity, NOT verified regulatory compliance or correctness of legacy business policies.
- No real cloud, LLM, IAM, HTTP gateway, external enterprise systems or deployed agents are bundled. Integration adapter is a local injectable mock.
- `contracts/legacy-api.yaml` represents contract-only endpoints, not an implemented server.
- Original legacy rule defects remain intentionally unresolved as participant investigation problems.
- Architecture candidates, ADRs and evaluation results must be produced by participants; no fabricated evidence or pre-selected winner.

## Included engineering assets per repo
- `README.md`, `PROMPTS.md`, `artifact-contract.yaml`
- `legacy/` runnable advisory-only code
- `data/schema.sql`, `data/fixtures.json`
- `contracts/` OpenAPI and JSON Schema samples
- `integrations/` mock gateway, explicit auth denial, injectable outage and snapshots
- `observability/` synthetic incident traces and duplicate/out-of-order events
- `docs/` domain brief, evidence catalog, NFR questions, scenarios, threat modelling starter and runbook
- `tests/` baseline and enhanced characterization suite
- `scripts/check_repo.py` integrity checker and `scripts/check_artifacts.py` participant deliverable presence checker

## Suggested participant evaluation
Require claim-to-evidence traceability, C4 boundaries that match discovered systems, minimum three candidate architectures, explicit non-AI alternative, independently enforced action authorization, measurable experiment design, trade-off sensitivity analysis, and ADR negative consequences with revisit triggers.

## Known limitations and honest scope
This is *production-grade design training material*, not production-ready operational software. Domain evidence remains synthetic and relatively compact. Regulators and safety requirements are represented as scenario constraints rather than a validated compliance implementation. Production deployment would require substantial engineering, independent domain review, realistic load data, IAM, privacy safeguards, supported integrations, control enforcement and live evals.
